﻿ALTER TABLE recipe_mod ADD COLUMN weenie_Class_Id INT NOT NULL DEFAULT 0;



UPDATE weenie_properties_int wi SET value = 14 WHERE wi.object_Id = 21081 AND wi.type = 3;
UPDATE weenie_properties_int wi SET value = 524296 WHERE wi.object_Id = 21081 AND wi.type = 16;
INSERT into weenie_properties_int (object_Id, type, value) VALUES (21081, 94, 33025);
UPDATE weenie_properties_string wi SET value = "Apply this material to a treasure-generated weapon to change it's damage type to Fire" WHERE wi.object_Id = 21081 AND wi.type = 14;

UPDATE weenie_properties_int wi SET value = 14 WHERE wi.object_Id = 21085 AND wi.type = 3;
UPDATE weenie_properties_int wi SET value = 524296 WHERE wi.object_Id = 21085 AND wi.type = 16;
INSERT into weenie_properties_int (object_Id, type, value) VALUES (21085, 94, 33025);
UPDATE weenie_properties_string wi SET value = "Apply this material to a treasure-generated weapon to change it's damage type to Cold" WHERE wi.object_Id = 21085 AND wi.type = 14;

UPDATE weenie_properties_int wi SET value = 14 WHERE wi.object_Id = 21075 AND wi.type = 3;
UPDATE weenie_properties_int wi SET value = 524296 WHERE wi.object_Id = 21075 AND wi.type = 16;
INSERT into weenie_properties_int (object_Id, type, value) VALUES (21075, 94, 33025);
UPDATE weenie_properties_string wi SET value = "Apply this material to a treasure-generated weapon to change it's damage type to Acid" WHERE wi.object_Id = 21075 AND wi.type = 14;

UPDATE weenie_properties_int wi SET value = 14 WHERE wi.object_Id = 21036 AND wi.type = 3;
UPDATE weenie_properties_int wi SET value = 524296 WHERE wi.object_Id = 21036 AND wi.type = 16;
INSERT into weenie_properties_int (object_Id, type, value) VALUES (21036, 94, 33025);
UPDATE weenie_properties_string wi SET value = "Apply this material to a treasure-generated weapon to change it's damage type to Lightning" WHERE wi.object_Id = 21036 AND wi.type = 14;

UPDATE weenie_properties_int wi SET value = 14 WHERE wi.object_Id = 21087 AND wi.type = 3;
UPDATE weenie_properties_int wi SET value = 524296 WHERE wi.object_Id = 21087 AND wi.type = 16;
INSERT into weenie_properties_int (object_Id, type, value) VALUES (21087, 94, 33025);
UPDATE weenie_properties_string wi SET value = "Apply this material to a treasure-generated weapon to change it's damage type to Slashing" WHERE wi.object_Id = 21087 AND wi.type = 14;

UPDATE weenie_properties_int wi SET value = 14 WHERE wi.object_Id = 21084 AND wi.type = 3;
UPDATE weenie_properties_int wi SET value = 524296 WHERE wi.object_Id = 21084 AND wi.type = 16;
INSERT into weenie_properties_int (object_Id, type, value) VALUES (21084, 94, 33025);
UPDATE weenie_properties_string wi SET value = "Apply this material to a treasure-generated weapon to change it's damage type to Piercing" WHERE wi.object_Id = 21084 AND wi.type = 14;

UPDATE weenie_properties_int wi SET value = 14 WHERE wi.object_Id = 21063 AND wi.type = 3;
UPDATE weenie_properties_int wi SET value = 524296 WHERE wi.object_Id = 21063 AND wi.type = 16;
INSERT into weenie_properties_int (object_Id, type, value) VALUES (21063, 94, 33025);
UPDATE weenie_properties_string wi SET value = "Apply this material to a treasure-generated weapon to change it's damage type to Bludgeoning" WHERE wi.object_Id = 21063 AND wi.type = 14;



INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 303 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3754, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3755, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3756, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3757, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3756 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 303, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3754, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3755, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3757, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3757 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 303, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3754, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3755, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3756, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3754 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 303, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3755, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3756, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3757, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3755 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 303, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3754, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3755, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3757, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 301 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3750, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3751, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3752, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3753, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3752 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 301, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3750, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3751, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3753, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3753 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 301, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3750, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3751, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3752, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3750 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 301, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3751, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3752, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3753, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3751 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 301, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3750, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3751, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3753, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 359 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3905, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3906, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3907, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3908, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3907 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 359, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3905, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3906, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3908, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3908 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 359, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3905, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3906, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3907, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3905 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 359, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3906, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3907, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3908, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3906 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 359, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3905, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3906, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3908, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 357 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3903, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3904, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3901, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3902, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3903 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 357, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3904, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3901, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3902, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3904 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 357, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3903, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3901, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3902, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3901 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 357, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3903, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3904, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3902, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3902 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 357, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3903, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3904, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3901, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 344 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3867, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3868, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3865, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3866, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3867 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 344, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3868, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3865, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3866, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3868 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 344, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3867, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3865, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3866, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3865 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 344, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3867, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3868, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3866, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3866 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 344, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3867, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3868, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3865, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 342 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3859, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3860, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3857, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3858, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3859 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 342, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3860, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3857, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3858, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3860 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 342, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3859, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3857, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3858, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3857 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 342, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3859, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3860, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3858, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3858 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 342, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3859, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3860, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3857, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 336 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3844, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3845, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3842, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3843, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3844 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 336, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3845, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3842, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3843, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3845 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 336, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3844, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3842, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3843, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3842 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 336, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3844, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3845, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3843, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3843 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 336, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3844, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3845, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3842, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 41052 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 41055, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 41056, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 41053, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 41054, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 41055 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41052, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41056, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41053, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41054, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 41056 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41052, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41055, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41053, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41054, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 41053 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41052, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41055, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41056, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41054, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 41054 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41052, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41055, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41056, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41053, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 329 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3832, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3833, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3830, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3831, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3832, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3833, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3830, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3831, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3832 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 329, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3833, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3830, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3831, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3833 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 329, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3832, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3830, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3831, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3830 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 329, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3832, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3833, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3831, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3831 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 329, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3832, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3833, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3830, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 314 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3780, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3781, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3778, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3779, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3780, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3781, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3778, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3779, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3780 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 314, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3781, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3778, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3779, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3781 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 314, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3780, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3778, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3779, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3778 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 314, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3780, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3781, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3779, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3779 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 314, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3780, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3781, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3778, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 22440 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 22443, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 22444, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 22441, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 22442, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 22443, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 22444, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 22441, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 22442, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 22443 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 22440, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 22444, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 22441, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 22442, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 22444 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 22440, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 22443, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 22441, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 22442, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 22441 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 22440, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 22443, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 22444, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 22442, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 22442 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 22440, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 22443, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 22444, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 22441, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 319 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3796, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3797, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3794, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3795, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3796, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3797, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3794, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3795, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3796 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 319, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3797, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3794, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3795, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3797 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 319, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3796, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3794, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3795, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3794 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 319, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3796, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3797, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3795, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3795 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 319, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3796, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3797, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3794, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 328 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3828, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3829, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3826, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3827, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3828, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3829, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3826, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3827, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3828 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 328, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3829, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3826, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3827, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3829 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 328, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3828, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3826, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3827, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3826 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 328, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3828, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3829, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3827, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3827 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 328, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3828, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3829, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3826, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 309 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3768, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3769, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3766, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3767, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3768 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 309, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3769, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3766, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3767, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3769 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 309, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3768, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3766, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3767, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3766 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 309, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3768, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3769, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3767, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3767 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 309, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3768, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3769, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3766, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 331 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3836, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3837, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3834, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3835, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3836 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 331, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3837, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3834, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3835, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3837 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 331, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3836, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3834, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3835, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3834 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 331, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3836, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3837, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3835, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3835 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 331, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3836, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3837, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3834, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 332 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3937, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3938, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3939, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3940, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3937 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 332, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3938, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3939, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3940, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3938 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 332, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3937, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3939, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3940, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3939 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 332, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3937, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3938, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3940, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3940 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 332, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3937, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3938, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3939, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 7768 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 7788, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 7787, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 7789, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 7790, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 7788 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 7768, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 7787, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 7789, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 7790, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 7787 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 7768, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 7788, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 7789, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 7790, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 7789 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 7768, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 7788, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 7787, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 7790, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 7790 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 7768, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 7788, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 7787, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 7789, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 325 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3816, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3817, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3814, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3815, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3816 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 325, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3817, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3814, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3815, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3817 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 325, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3816, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3814, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3815, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3814 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 325, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3816, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3817, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3815, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3815 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 325, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3816, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3817, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3814, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 313 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3776, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3777, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3774, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3775, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3776 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 313, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3777, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3774, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3775, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3777 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 313, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3776, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3774, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3775, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3774 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 313, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3776, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3777, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3775, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3775 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 313, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3776, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3777, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3774, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 321 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3804, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3805, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3802, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3803, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3804 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 321, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3805, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3802, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3803, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3805 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 321, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3804, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3802, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3803, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3802 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 321, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3804, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3805, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3803, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3803 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 321, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3804, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3805, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3802, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 356 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3899, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3900, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3897, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3898, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3899 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 356, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3900, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3897, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3898, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3900 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 356, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3899, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3897, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3898, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3897 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 356, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3899, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3900, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3898, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3898 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 356, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3899, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3900, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3897, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 41057 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 41060, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 41061, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 41058, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 41059, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 41060 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41057, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41061, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41058, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41059, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 41061 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41057, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41060, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41058, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41059, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 41058 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41057, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41060, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41061, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41059, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 41059 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41057, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41060, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41061, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41058, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 41062 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 41065, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 41066, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 41063, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 41064, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 41065 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41062, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41066, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41063, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41064, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 41066 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41062, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41065, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41063, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41064, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 41063 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41062, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41065, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41066, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41064, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 41064 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41062, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41065, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41066, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41063, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 40635 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 40638, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 40639, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 40636, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 40637, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 40638 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 40635, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 40639, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 40636, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 40637, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 40639 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 40635, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 40638, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 40636, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 40637, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 40636 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 40635, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 40638, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 40639, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 40637, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 40637 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 40635, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 40638, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 40639, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 40636, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 348 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3875, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3876, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3873, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3874, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3875 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 348, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3876, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3873, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3874, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3876 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 348, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3875, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3873, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3874, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3873 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 348, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3875, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3876, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3874, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3874 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 348, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3875, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3876, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3873, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 7772 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 7792, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 7791, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 7793, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 7794, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 7792 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 7772, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 7791, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 7793, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 7794, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 7791 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 7772, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 7792, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 7793, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 7794, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 7793 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 7772, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 7792, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 7791, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 7794, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 7794 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 7772, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 7792, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 7791, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 7793, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 7771 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 7796, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 7795, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 7797, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 7798, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 7796, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 7795, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 7797, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 7798, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 7796 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 7771, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 7795, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 7797, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 7798, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 7795 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 7771, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 7796, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 7797, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 7798, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 7797 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 7771, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 7796, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 7795, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 7798, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 7798 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 7771, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 7796, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 7795, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 7797, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 308 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3764, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3765, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3762, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3763, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3764 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 308, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3765, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3762, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3763, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3765 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 308, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3764, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3762, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3763, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3762 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 308, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3764, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3765, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3763, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3763 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 308, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3764, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3765, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3762, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 362 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3915, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3916, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3913, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3914, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3915 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 362, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3916, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3913, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3914, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3916 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 362, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3915, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3913, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3914, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3913 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 362, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3915, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3916, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3914, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3914 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 362, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3915, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3916, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3913, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 41046 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 41049, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 41050, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 41047, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 41048, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 41049 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41046, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41050, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41047, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41048, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 41050 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41046, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41049, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41047, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41048, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 41047 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41046, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41049, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41050, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41048, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 41048 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41046, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41049, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41050, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41047, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 41036 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 41039, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 41040, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 41037, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 41038, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 41039 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41036, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41040, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41037, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41038, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 41040 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41036, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41039, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41037, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41038, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 41037 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41036, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41039, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41040, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41038, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 41038 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41036, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41039, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41040, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41037, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 41041 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 41044, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 41045, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 41042, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 41043, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 41044 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41041, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41045, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41042, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41043, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 41045 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41041, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41044, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41042, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41043, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 41042 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41041, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41044, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41045, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41043, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 41043 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41041, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41044, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41045, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41042, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 22168 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 22166, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 22167, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 22164, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 22165, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 22166 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 22168, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 22167, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 22164, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 22165, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 22167 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 22168, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 22166, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 22164, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 22165, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 22164 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 22168, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 22166, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 22167, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 22165, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 22165 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 22168, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 22166, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 22167, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 22164, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 22163 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 22161, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 22162, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 22159, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 22160, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 22161 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 22163, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 22162, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 22159, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 22160, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 22162 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 22163, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 22161, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 22159, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 22160, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 22159 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 22163, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 22161, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 22162, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 22160, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 22160 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 22163, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 22161, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 22162, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 22159, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 22158 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 22156, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 22157, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 22154, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 22155, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 22156 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 22158, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 22157, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 22154, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 22155, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 22157 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 22158, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 22156, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 22154, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 22155, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 22154 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 22158, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 22156, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 22157, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 22155, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 22155 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 22158, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 22156, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 22157, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 22154, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 338 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3936, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3848, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3846, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3847, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3936 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 338, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3848, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3846, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3847, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3848 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 338, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3936, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3846, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3847, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3846 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 338, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3936, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3848, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3847, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3847 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 338, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3936, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3848, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3846, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 333 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3840, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3841, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3838, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3839, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3840 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 333, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3841, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3838, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3839, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3841 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 333, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3840, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3838, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3839, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3838 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 333, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3840, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3841, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3839, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3839 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 333, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3840, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3841, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3838, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 322 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3808, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3809, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3806, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3807, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3808 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 322, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3809, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3806, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3807, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3809 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 322, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3808, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3806, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3807, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3806 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 322, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3808, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3809, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3807, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3807 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 322, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3808, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3809, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3806, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 352 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3887, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3888, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3885, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3886, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3887, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3888, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3885, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3886, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3887 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 352, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3888, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3885, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3886, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3888 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 352, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3887, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3885, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3886, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3885 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 352, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3887, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3888, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3886, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3886 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 352, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3887, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3888, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3885, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 339 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3851, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3852, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3849, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3850, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3851, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3852, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3849, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3850, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3851 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 339, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3852, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3849, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3850, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3852 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 339, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3851, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3849, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3850, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3849 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 339, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3851, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3852, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3850, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3850 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 339, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3851, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3852, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3849, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 351 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3883, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3884, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3881, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3882, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3883, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3884, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3881, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3882, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3883 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 351, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3884, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3881, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3882, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3884 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 351, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3883, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3881, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3882, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3881 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 351, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3883, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3884, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3882, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3882 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 351, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3883, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3884, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3881, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 350 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3879, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3880, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3877, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3878, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3879, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3880, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3877, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3878, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3879 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 350, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3880, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3877, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3878, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3880 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 350, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3879, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3877, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3878, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3877 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 350, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3879, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3880, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3878, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3878 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 350, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3879, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3880, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3877, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 40618 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 40621, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 40622, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 40619, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 40620, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 40621 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 40618, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 40622, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 40619, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 40620, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 40622 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 40618, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 40621, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 40619, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 40620, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 40619 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 40618, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 40621, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 40622, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 40620, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 40620 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 40618, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 40621, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 40622, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 40619, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 345 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3871, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3872, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3869, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3870, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3871, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3872, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3869, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3870, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3871 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 345, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3872, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3869, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3870, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3872 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 345, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3871, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3869, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3870, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3869 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 345, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3871, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3872, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3870, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3870 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 345, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3871, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3872, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3869, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 324 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3812, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3813, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3810, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3811, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3812, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3813, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3810, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3811, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3812 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 324, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3813, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3810, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3811, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3813 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 324, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3812, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3810, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3811, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3810 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 324, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3812, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3813, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3811, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3811 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 324, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3812, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3813, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3810, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 340 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3855, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3856, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3853, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3854, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3855, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3856, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3853, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3854, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3855 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 340, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3856, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3853, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3854, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3856 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 340, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3855, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3853, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3854, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3853 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 340, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3855, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3856, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3854, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3854 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 340, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3855, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3856, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3853, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 354 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3895, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3896, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3893, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3894, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3895, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3896, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3893, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3894, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3895 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 354, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3896, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3893, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3894, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3896 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 354, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3895, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3893, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3894, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3893 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 354, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3895, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3896, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3894, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3894 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 354, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3895, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3896, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3893, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 41067 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 41070, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 41071, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 41068, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 41069, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 41070 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41067, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41071, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41068, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 41069, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 41071 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41067, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41070, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41068, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 41069, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 41068 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41067, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41070, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41071, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 41069, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 41069 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41067, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41070, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41071, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 41068, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 361 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3911, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3912, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3909, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3910, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3911, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3912, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3909, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3910, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3911 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 361, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3912, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3909, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3910, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3912 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 361, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3911, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3909, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3910, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3909 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 361, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3911, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3912, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3910, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3910 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 361, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3911, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3912, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3909, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 327 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3824, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3825, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3822, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3823, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3824, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3825, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3822, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3823, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3824 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 327, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3825, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3822, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3823, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3825 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 327, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3824, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3822, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3823, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3822 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 327, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3824, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3825, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3823, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3823 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 327, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3824, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3825, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3822, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 353 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3891, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3892, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3889, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3890, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3891, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3892, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3889, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3890, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3891 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 353, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3892, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3889, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3890, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3892 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 353, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3891, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3889, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3890, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3889 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 353, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3891, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3892, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3890, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3890 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 353, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3891, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3892, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3889, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 40760 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 40763, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 40764, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 40761, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 40762, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 40763 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 40760, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 40764, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 40761, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 40762, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 40764 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 40760, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 40763, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 40761, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 40762, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 40761 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 40760, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 40763, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 40764, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 40762, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 40762 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 40760, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 40763, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 40764, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 40761, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 4190 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 4191, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 4193, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 4192, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 4194, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 4191 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 4190, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 4193, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 4192, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 4194, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 4193 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 4190, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 4191, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 4192, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 4194, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 4192 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 4190, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 4191, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 4193, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 4194, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 4194 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 4190, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 4191, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 4193, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 4192, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 326 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3820, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3821, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3818, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3819, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3820, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3821, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3818, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3819, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3820 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 326, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3821, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3818, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3819, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3821 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 326, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3820, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3818, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3819, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3818 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 326, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3820, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3821, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3819, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3819 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 326, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3820, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3821, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3818, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 4195 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 4196, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 4198, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 4197, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 4199, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 4196 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 4195, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 4198, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 4197, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 4199, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 4198 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 4195, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 4196, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 4197, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 4199, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 4197 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 4195, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 4196, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 4198, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 4199, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 4199 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 4195, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 4196, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 4198, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 4197, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 316 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3788, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3789, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3786, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3787, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3788 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 316, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3789, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3786, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3787, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3789 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 316, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3788, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3786, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3787, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3786 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 316, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3788, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3789, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3787, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3787 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 316, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3788, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3789, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3786, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 304 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3760, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3761, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3758, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 3759, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3760 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 304, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3761, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3758, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3759, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3761 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 304, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3760, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3758, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3759, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3758 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 304, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3760, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3761, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3759, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3759 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 304, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3760, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3761, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3758, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 310 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3772, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3773, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3770, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 3771, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3772 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 310, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3773, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3770, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3771, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3773 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 310, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3772, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3770, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3771, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3770 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 310, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3772, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3773, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3771, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3771 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 310, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3772, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3773, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3770, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 315 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3784, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3785, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3782, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3783, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3784 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 315, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3785, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3782, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3783, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3785 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 315, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3784, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3782, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3783, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3782 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 315, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3784, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3785, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3783, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3783 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 315, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3784, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3785, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3782, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 320 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3800, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3801, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3798, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3799, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3800 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 320, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3801, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3798, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3799, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3801 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 320, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3800, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3798, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3799, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3798 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 320, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3800, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3801, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3799, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3799 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 320, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3800, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3801, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3798, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 343 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3863, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3864, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3861, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3862, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3863 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 343, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3864, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3861, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3862, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3864 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 343, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3863, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3861, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3862, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3861 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 343, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3863, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3864, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3862, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3862 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 343, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3863, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3864, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3861, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the onyx.", 0, 0, "You apply the onyx, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524176, 0, 0, 317 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3792, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3793, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3790, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 3791, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 3792 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 317, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3793, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3790, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 3791, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 3793 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 317, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3792, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3790, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 3791, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 3790 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 317, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3792, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3793, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 3791, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 3791 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 317, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3792, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3793, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 3790, "2022-12-19 10:00:00" FROM recipe;



INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the yellow garnet.", 0, 0, "You apply the yellow garnet, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524181, 0, 0, 29258 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29257, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29253, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29255, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29256, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29252, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29254, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white jade.", 0, 0, "You apply the white jade, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524181, 0, 0, 29257 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29258, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29253, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29255, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29256, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29252, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29254, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the obsidian.", 0, 0, "You apply the obsidian, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524182, 0, 0, 29253 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29258, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29257, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29255, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29256, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29252, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29254, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 29255 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29258, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29257, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29253, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29256, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29252, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29254, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 29256 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29258, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29257, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29253, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29255, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29252, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29254, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 29252 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29258, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29257, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29253, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29255, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29256, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29254, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 29254 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29258, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29257, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29253, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29255, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29256, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29252, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the yellow garnet.", 0, 0, "You apply the yellow garnet, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524181, 0, 0, 29244 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29243, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29239, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29241, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29242, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29238, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29240, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white jade.", 0, 0, "You apply the white jade, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524181, 0, 0, 29243 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29244, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29239, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29241, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29242, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29238, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29240, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the obsidian.", 0, 0, "You apply the obsidian, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524182, 0, 0, 29239 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29244, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29243, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29241, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29242, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29238, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29240, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 29241 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29244, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29243, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29239, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29242, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29238, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29240, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 29242 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29244, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29243, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29239, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29241, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29238, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29240, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 29238 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29244, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29243, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29239, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29241, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29242, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29240, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 29240 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29244, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29243, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29239, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29241, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29242, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29238, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the yellow garnet.", 0, 0, "You apply the yellow garnet, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524181, 0, 0, 29251 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29250, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29246, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29248, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29249, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29245, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29247, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white jade.", 0, 0, "You apply the white jade, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524181, 0, 0, 29250 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29251, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29246, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29248, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29249, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29245, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29247, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the obsidian.", 0, 0, "You apply the obsidian, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524182, 0, 0, 29246 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29251, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29250, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29248, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29249, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29245, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29247, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 29248 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29251, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29250, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29246, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29249, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29245, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29247, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 29249 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29251, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29250, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29246, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29248, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29245, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29247, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 29245 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29251, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29250, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29246, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29248, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29249, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29247, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 29247 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29251, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29250, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29246, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29248, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29249, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29245, "2022-12-19 10:00:00" FROM recipe;

INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the yellow garnet.", 0, 0, "You apply the yellow garnet, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524181, 0, 0, 29265 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29264, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29260, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29262, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29263, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29259, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21087, 29261, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white jade.", 0, 0, "You apply the white jade, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524181, 0, 0, 29264 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29265, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29260, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29262, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29263, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29259, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21084, 29261, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the obsidian.", 0, 0, "You apply the obsidian, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524182, 0, 0, 29260 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29265, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29264, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29262, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29263, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29259, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21063, 29261, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the tiger eye.", 0, 0, "You apply the tiger eye, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524177, 0, 0, 29262 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29265, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29264, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29260, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29263, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29259, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21081, 29261, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the white quartz.", 0, 0, "You apply the white quartz, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524178, 0, 0, 29263 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29265, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29264, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29260, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29262, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29259, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21085, 29261, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the serpentine.", 0, 0, "You apply the serpentine, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524179, 0, 0, 29259 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29265, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29264, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29260, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29262, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29263, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21075, 29261, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe (id, unknown_1, skill, difficulty, salvage_Type, success_W_C_I_D, success_Amount, success_Message, fail_W_C_I_D, fail_Amount, fail_Message, success_Destroy_Source_Chance, success_Destroy_Source_Amount, success_Destroy_Source_Message, success_Destroy_Target_Chance, success_Destroy_Target_Amount, success_Destroy_Target_Message, fail_Destroy_Source_Chance, fail_Destroy_Source_Amount, fail_Destroy_Source_Message, fail_Destroy_Target_Chance, fail_Destroy_Target_Amount, fail_Destroy_Target_Message, data_Id, last_Modified)
SELECT MAX(id) + 1, 0, 28, 0, 1, 0, 0, "You apply the amethyst.", 0, 0, "You apply the amethyst, but in the process you destroy the target.", 1, 1, NULL, 0, 0, NULL, 1, 1, NULL, 1, 1, NULL, 0, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO recipe_mod (recipe_Id, executes_On_Success, health, stamina, mana, unknown_7, data_Id, unknown_9, instance_Id, weenie_Class_Id)
SELECT MAX(id), 0x01, 0, 0, 0, 0x00, 939524180, 0, 0, 29261 FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29265, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29264, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29260, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29262, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29263, "2022-12-19 10:00:00" FROM recipe;
INSERT INTO cook_book (recipe_Id, source_W_C_I_D, target_W_C_I_D, last_Modified)
SELECT MAX(id), 21036, 29259, "2022-12-19 10:00:00" FROM recipe;
